// Kadın Elbiseleri e-ticaret - tüm özellikli JS
const products = [
  {id:1, title:"Çiçek Desenli Yaz Elbisesi", price:249.90, desc:"Hafif kumaş, midi boy. Günlük ve özel davetler için.", img:"https://picsum.photos/seed/d1/800/600", colors:["#fbcfe8","#fde68a","#f472b6"], sizes:["S","M","L"], featured:true, category:"Günlük"},
  {id:2, title:"Siyah Kokteyl Elbise", price:499.00, desc:"Davetlerin vazgeçilmezi, klasik kesim.", img:"https://picsum.photos/seed/d2/800/600", colors:["#111827","#6b7280"], sizes:["XS","S","M"], featured:true, category:"Kokteyl"},
  {id:3, title:"Günlük Oversize Elbise", price:199.90, desc:"Rahat kesim, cep detaylı.", img:"https://picsum.photos/seed/d3/800/600", colors:["#60a5fa","#34d399"], sizes:["M","L","XL"], featured:false, category:"Günlük"},
  {id:4, title:"Keten Plaj Elbisesi", price:179.90, desc:"Nefes alır, plaj ve yaz gezileri için ideal.", img:"https://picsum.photos/seed/d4/800/600", colors:["#fef3c7","#a78bfa"], sizes:["S","M","L"], featured:false, category:"Plaj"},
  {id:5, title:"Kot Görünümlü Elbise", price:289.50, desc:"Spor ve şık — günlük kombinler için.", img:"https://picsum.photos/seed/d5/800/600", colors:["#60a5fa","#6b7280"], sizes:["S","M","L"], featured:false, category:"Günlük"},
  {id:6, title:"Abiye Uzun Elbise", price:899.00, desc:"Özel geceler için gösterişli uzun elbise.", img:"https://picsum.photos/seed/d6/800/600", colors:["#0ea5a4","#ef4444"], sizes:["S","M"], featured:true, category:"Abiye"}
];

const CART_KEY = "dresses_ecom_cart_v2";

let cart = loadCart();

const productsEl = document.getElementById("products");
const cartCountEl = document.getElementById("cart-count");
const cartButton = document.getElementById("cart-button");
const cartDrawer = document.getElementById("cart-drawer");
const overlay = document.getElementById("overlay");
const closeCartBtn = document.getElementById("close-cart");
const cartItemsEl = document.getElementById("cart-items");
const cartTotalEl = document.getElementById("cart-total");
const checkoutBtn = document.getElementById("checkout");
const clearCartBtn = document.getElementById("clear-cart");
const searchInput = document.getElementById("search");
const showFeaturedBtn = document.getElementById("show-featured");
const catBtns = document.querySelectorAll(".cat-btn");
const themeToggle = document.getElementById("theme-toggle");

// Modal elements
const modal = document.getElementById("product-modal");
const modalOverlay = document.getElementById("modal-overlay");
const modalClose = document.getElementById("modal-close");
const modalImg = document.getElementById("modal-img");
const modalTitle = document.getElementById("modal-title");
const modalDesc = document.getElementById("modal-desc");
const modalPrice = document.getElementById("modal-price");
const modalSizes = document.getElementById("modal-sizes");
const modalColors = document.getElementById("modal-colors");
const modalQty = document.getElementById("modal-qty");
const modalDec = document.getElementById("modal-dec");
const modalInc = document.getElementById("modal-inc");
const modalAdd = document.getElementById("modal-add");
const modalBuy = document.getElementById("modal-buy");

let currentModalProduct = null;
let currentSelectedSize = null;
let currentSelectedColor = null;

function saveCart(){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); renderCart(); }
function loadCart(){ try{ const raw = localStorage.getItem(CART_KEY); return raw ? JSON.parse(raw) : {}; }catch(e){ return {}; } }

function renderProducts(filterText = "", onlyFeatured = false, category = ""){
  productsEl.innerHTML = "";
  const q = String(filterText||"").trim().toLowerCase();
  const list = products.filter(p=>{
    if(onlyFeatured && !p.featured) return false;
    if(category && category.length>0 && p.category !== category) return false;
    if(!q) return true;
    return (p.title + " " + p.desc).toLowerCase().includes(q);
  });
  if(list.length===0){
    productsEl.innerHTML = `<div style="padding:20px;color:#6b7280">Aradığınız kriterlere uygun ürün bulunamadı.</div>`;
    return;
  }
  list.forEach(p=>{
    const card = document.createElement("article");
    card.className = "card";
    const badgeHtml = p.featured ? `<div class="badge">Dikkat Çekici</div>` : "";
    const swatchesHtml = (p.colors||[]).slice(0,4).map((c,idx)=>`<div class="swatch" title="${c}" style="background:${c}" data-color="${c}" data-id="${p.id}"></div>`).join("");
    card.innerHTML = `
      ${badgeHtml}
      <img src="${p.img}" alt="${escapeHtml(p.title)}">
      <div class="title">${escapeHtml(p.title)}</div>
      <div class="meta">${escapeHtml(p.desc)}</div>
      <div class="price">${p.price.toFixed(2)} ₺</div>
      <div class="swatches">${swatchesHtml}</div>
      <div class="actions">
        <button class="btn detail-btn" data-id="${p.id}">Detay</button>
        <button class="btn-primary add-btn" data-id="${p.id}">Sepete Ekle</button>
      </div>
    `;
    productsEl.appendChild(card);
  });
  // wire buttons
  productsEl.querySelectorAll(".add-btn").forEach(btn=>{
    btn.addEventListener("click", ()=> addToCart(Number(btn.dataset.id),1));
  });
  productsEl.querySelectorAll(".detail-btn").forEach(btn=>{
    btn.addEventListener("click", ()=> openModal(Number(btn.dataset.id)));
  });
  // clicking swatch previews modal image
  productsEl.querySelectorAll(".swatch").forEach(s=>{
    s.addEventListener("click", (e)=>{
      const id = Number(s.dataset.id);
      const p = products.find(x=>x.id===id);
      if(!p) return;
      // open small preview: change image src briefly (use seed color)
      // fallback: open modal of product
      openModal(id);
      // select color in modal automatically
    });
  });
}

function addToCart(productId, qty=1, opts={}){
  const p = products.find(x=>x.id===productId);
  if(!p) return;
  // key includes chosen color/size to distinguish variants
  const variantKey = `${productId}::${opts.size||""}::${opts.color||""}`;
  if(!cart[variantKey]) cart[variantKey] = {...p, quantity:0, variant:{size:opts.size||null, color:opts.color||null}, id:productId};
  cart[variantKey].quantity += qty;
  saveCart();
  openCart();
}

function renderCart(){
  const items = Object.values(cart);
  const totalCount = items.reduce((s,i)=>s+i.quantity,0);
  cartCountEl.textContent = totalCount;
  cartItemsEl.innerHTML = "";
  if(items.length===0){
    cartItemsEl.innerHTML = `<div style="padding:12px;color:#6b7280">Sepet boş.</div>`;
  } else {
    items.forEach((item,idx)=>{
      const div = document.createElement("div");
      div.className = "cart-item";
      const variantLine = (item.variant && (item.variant.size || item.variant.color)) ? `<div style="font-size:0.9rem;color:#6b7280">${item.variant.size ? "Beden: "+item.variant.size : ""} ${item.variant.color ? " • Renk" : ""}</div>` : "";
      div.innerHTML = `
        <img src="${item.img}" alt="${escapeHtml(item.title)}">
        <div class="meta">
          <div style="font-weight:600">${escapeHtml(item.title)}</div>
          ${variantLine}
          <div style="color:#374151">${item.price.toFixed(2)} ₺</div>
          <div class="qty-controls">
            <button class="btn cart-dec" data-idx="${idx}">-</button>
            <div style="min-width:28px;text-align:center">${item.quantity}</div>
            <button class="btn cart-inc" data-idx="${idx}">+</button>
            <button class="btn cart-remove" data-idx="${idx}" style="margin-left:8px;color:#ef4444">Sil</button>
          </div>
        </div>
      `;
      cartItemsEl.appendChild(div);
    });
    // wire cart item buttons by index
    cartItemsEl.querySelectorAll(".cart-inc").forEach(b=>{
      b.addEventListener("click", ()=>{
        const i = Number(b.dataset.idx);
        const keys = Object.keys(cart);
        const k = keys[i];
        cart[k].quantity++;
        saveCart();
      });
    });
    cartItemsEl.querySelectorAll(".cart-dec").forEach(b=>{
      b.addEventListener("click", ()=>{
        const i = Number(b.dataset.idx);
        const keys = Object.keys(cart);
        const k = keys[i];
        cart[k].quantity--;
        if(cart[k].quantity<=0) delete cart[k];
        saveCart();
      });
    });
    cartItemsEl.querySelectorAll(".cart-remove").forEach(b=>{
      b.addEventListener("click", ()=>{
        const i = Number(b.dataset.idx);
        const keys = Object.keys(cart);
        const k = keys[i];
        delete cart[k];
        saveCart();
      });
    });
  }
  const total = Object.values(cart).reduce((s,i)=>s + i.price * i.quantity, 0);
  cartTotalEl.textContent = total.toFixed(2);
}

function clearCart(){ cart = {}; saveCart(); }

function openCart(){ cartDrawer.classList.add("open"); cartDrawer.setAttribute("aria-hidden","false"); overlay.classList.remove("hidden"); overlay.style.display = "block"; renderCart(); }
function closeCart(){ cartDrawer.classList.remove("open"); cartDrawer.setAttribute("aria-hidden","true"); overlay.style.display = "none"; overlay.classList.add("hidden"); }

cartButton.addEventListener("click", openCart);
closeCartBtn.addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);
checkoutBtn.addEventListener("click", ()=>{
  const items = Object.values(cart);
  if(items.length===0){ alert("Sepet boş."); return; }
  alert("Satın alma simülasyonu: Ödeme sayfasına yönlendiriliyormuş gibi davranıldı.\nTeşekkürler!");
  clearCart();
  closeCart();
});
clearCartBtn.addEventListener("click", ()=>{ if(confirm("Sepeti tamamen temizlemek istiyor musunuz?")) clearCart(); });

searchInput.addEventListener("input", (e)=>{ renderProducts(e.target.value, false, getActiveCategory()); });
showFeaturedBtn.addEventListener("click", ()=>{
  const only = showFeaturedBtn.dataset.only === "1";
  if(!only){
    renderProducts("", true, getActiveCategory());
    showFeaturedBtn.textContent = "Tümünü Göster";
    showFeaturedBtn.dataset.only = "1";
  } else {
    renderProducts("", false, getActiveCategory());
    showFeaturedBtn.textContent = "Öne Çıkanları Göster";
    showFeaturedBtn.dataset.only = "0";
  }
});

// category buttons
catBtns.forEach(b=>{
  b.addEventListener("click", ()=>{
    catBtns.forEach(x=>x.classList.remove("active"));
    b.classList.add("active");
    renderProducts(searchInput.value, showFeaturedBtn.dataset.only === "1", getActiveCategory());
  });
});
function getActiveCategory(){
  const active = document.querySelector(".cat-btn.active");
  return active ? active.dataset.cat : "";
}

// Theme toggle
let theme = 0;
themeToggle.addEventListener("click", ()=>{
  theme = (theme + 1) % 2;
  if(theme===0){
    document.documentElement.style.setProperty("--accent", "#d946ef");
  } else {
    document.documentElement.style.setProperty("--accent", "#0ea5a4");
  }
});

// Modal logic
function openModal(productId){
  const p = products.find(x=>x.id===productId);
  if(!p) return;
  currentModalProduct = p;
  currentSelectedSize = p.sizes && p.sizes.length ? p.sizes[0] : null;
  currentSelectedColor = p.colors && p.colors.length ? p.colors[0] : null;
  modalImg.src = p.img;
  modalImg.alt = p.title;
  modalTitle.textContent = p.title;
  modalDesc.textContent = p.desc;
  modalPrice.textContent = p.price.toFixed(2) + " ₺";
  // sizes
  modalSizes.innerHTML = (p.sizes||[]).map(s=>`<button class="btn size-btn" data-size="${s}">${s}</button>`).join(" ");
  // colors
  modalColors.innerHTML = (p.colors||[]).map(c=>`<div class="swatch" style="background:${c}" data-color="${c}"></div>`).join("");
  modalQty.value = 1;
  // wire up selections
  modalSizes.querySelectorAll(".size-btn").forEach(b=>{
    if(b.dataset.size === currentSelectedSize) b.classList.add("selected");
    b.addEventListener("click", ()=>{
      modalSizes.querySelectorAll(".size-btn").forEach(x=>x.classList.remove("selected"));
      b.classList.add("selected");
      currentSelectedSize = b.dataset.size;
    });
  });
  modalColors.querySelectorAll(".swatch").forEach(s=>{
    if(s.dataset.color === currentSelectedColor) s.classList.add("selected");
    s.addEventListener("click", ()=>{
      modalColors.querySelectorAll(".swatch").forEach(x=>x.classList.remove("selected"));
      s.classList.add("selected");
      currentSelectedColor = s.dataset.color;
    });
  });
  // qty buttons
  modalDec.onclick = ()=>{ modalQty.value = Math.max(1, Number(modalQty.value)-1); };
  modalInc.onclick = ()=>{ modalQty.value = Math.max(1, Number(modalQty.value)+1); };
  modalAdd.onclick = ()=>{
    const qty = Math.max(1, Number(modalQty.value)||1);
    addToCart(p.id, qty, {size: currentSelectedSize, color: currentSelectedColor});
    closeModal();
  };
  modalBuy.onclick = ()=>{
    alert("Hemen al (simülasyon). Ödeme sayfasına yönlendiriliyormuş gibi davranıldı.");
    closeModal();
  };
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden","false");
  modalOverlay.classList.remove("hidden");
}

function closeModal(){
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden","true");
  modalOverlay.classList.add("hidden");
}
modalClose.addEventListener("click", closeModal);
modalOverlay.addEventListener("click", closeModal);

// helpers
function escapeHtml(s){ return String(s).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;"); }

// init
renderProducts();
renderCart();